﻿using Lifestyle.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Lifestyle.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminloginController : ControllerBase
    {
        private readonly MyDatabaseContext con;

        public AdminloginController(MyDatabaseContext context)
        {
            con = context;
        }
        // GET api/<ValuesController>/5
        [HttpGet("{Id}")]
        public IActionResult GetById(int Id)
        {
            var Stud = con.Adminlogin.Find(Id);
            if (Stud == null)
                return NotFound();
            return Ok(Stud);
        }
        [HttpGet]
        public IActionResult Get()
        {
            var login = con.Adminlogin.ToList();
            return Ok(login);
        }
        [HttpPost]
        public IActionResult Create(AdminLogin admin)
        {
            con.Adminlogin.Add(admin);
            con.SaveChanges();
            return CreatedAtAction(nameof(GetById), new { Id = admin.AdminID }, admin);
        }

        // PUT api/<ValuesController>/5
        [HttpPut("{Id}")]
        public IActionResult Put(int Id, AdminLogin data)
        {
            var existingAdmin = con.Adminlogin.Find(Id);

            if (existingAdmin == null)
            {
                return NotFound();
            }

            existingAdmin.FirstName = data.FirstName;
            existingAdmin.LastName = data.LastName;
            existingAdmin.Email = data.Email;
            existingAdmin.Password = data.Password;
            con.SaveChanges();

            return Ok(existingAdmin);
        }
    }
}

