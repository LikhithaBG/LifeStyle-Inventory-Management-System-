﻿using Microsoft.EntityFrameworkCore;
using Lifestyle.Models;

namespace Lifestyle.Models
{
    public class MyDatabaseContext : DbContext
    {
        public MyDatabaseContext(DbContextOptions<MyDatabaseContext> options)
            : base(options)
        {
        }
        public DbSet<AdminLogin> Adminlogin { get; set; }
    }
}
